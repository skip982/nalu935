//
//  ViewController.m
//  Nalu
//
//  Created by skip982 on 5/9/17.
//  Copyright © 2017 skip982. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

int count;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (IBAction)btnJelbrekMe:(id)sender {
    // TODO: Add the exploit code here...
    
    // This is just a basic count on how many times the "Go" button is pressed.
    
    count++;
    printf("%d%s\n", count , " GO has been pressed.");
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskAll;
}


@end
