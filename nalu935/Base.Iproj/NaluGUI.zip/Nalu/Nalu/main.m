//
//  main.m
//  Nalu
//
//  Created by Grzegorz Lew on 5/9/17.
//  Copyright © 2017 skip982. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
